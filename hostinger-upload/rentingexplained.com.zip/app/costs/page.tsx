import Link from 'next/link';
import { generateMetadata as genMeta } from '@/lib/metadata';

export const metadata = genMeta({
  title: 'Costs & Savings - Money-Saving Strategies for Renters',
  description: 'Learn how to save money on rent, understand rental costs, and make smart financial decisions as a renter.',
  path: '/costs',
});

export default function CostsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-br from-green-600 to-emerald-700 text-white py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Costs & Savings</h1>
          <p className="text-xl text-green-100 max-w-2xl">
            Money-saving strategies and cost breakdowns for smart renters
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-5xl mx-auto">
          <div className="bg-white rounded-xl shadow-md p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">?? Your Rental Financial Hub</h2>
            <p className="text-gray-700 mb-6">
              Rent is likely your biggest monthly expense. This hub brings together everything you need to 
              understand rental costs, find savings opportunities, and make smart financial decisions.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-green-50 rounded-lg p-6 text-center">
                <div className="text-4xl mb-2">??</div>
                <h3 className="font-semibold text-gray-900 mb-1">Average Savings</h3>
                <p className="text-3xl font-bold text-green-600">$2,400</p>
                <p className="text-sm text-gray-600">per year using our strategies</p>
              </div>
              
              <div className="bg-blue-50 rounded-lg p-6 text-center">
                <div className="text-4xl mb-2">??</div>
                <h3 className="font-semibold text-gray-900 mb-1">Budget Rule</h3>
                <p className="text-3xl font-bold text-blue-600">30%</p>
                <p className="text-sm text-gray-600">of income maximum for rent</p>
              </div>
              
              <div className="bg-purple-50 rounded-lg p-6 text-center">
                <div className="text-4xl mb-2">??</div>
                <h3 className="font-semibold text-gray-900 mb-1">Hidden Fees</h3>
                <p className="text-3xl font-bold text-purple-600">15-30%</p>
                <p className="text-sm text-gray-600">above advertised rent</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Link href="/blog/how-to-save-money-renting-2025" className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow border-l-4 border-green-500">
              <div className="text-3xl mb-3">??</div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">How to Save Money Renting</h3>
              <p className="text-gray-600 mb-4">
                Expert strategies to slash your rental costs by $50-300/month
              </p>
              <div className="text-green-600 font-medium">
                Read full guide ?
              </div>
            </Link>

            <Link href="/blog/hidden-rental-fees-explained" className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow border-l-4 border-blue-500">
              <div className="text-3xl mb-3">??</div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Hidden Rental Fees Explained</h3>
              <p className="text-gray-600 mb-4">
                Understand the true cost of renting and avoid surprise charges
              </p>
              <div className="text-blue-600 font-medium">
                Read full guide ?
              </div>
            </Link>

            <Link href="/blog/renting-vs-buying-2025" className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow border-l-4 border-purple-500">
              <div className="text-3xl mb-3">??</div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Renting vs Buying 2025</h3>
              <p className="text-gray-600 mb-4">
                Complete financial analysis: when renting actually wins
              </p>
              <div className="text-purple-600 font-medium">
                Read full guide ?
              </div>
            </Link>

            <Link href="/tools/rent-budget-checker" className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow border-l-4 border-orange-500">
              <div className="text-3xl mb-3">??</div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Rent Budget Calculator</h3>
              <p className="text-gray-600 mb-4">
                Calculate how much rent you can actually afford
              </p>
              <div className="text-orange-600 font-medium">
                Use calculator ?
              </div>
            </Link>

            <Link href="/tools/hidden-fees-estimator" className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow border-l-4 border-red-500">
              <div className="text-3xl mb-3">??</div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Hidden Fees Estimator</h3>
              <p className="text-gray-600 mb-4">
                Calculate your true monthly rental cost with all fees
              </p>
              <div className="text-red-600 font-medium">
                Use calculator ?
              </div>
            </Link>

            <div className="bg-white rounded-xl shadow-md p-6 opacity-60 border-l-4 border-gray-300">
              <div className="text-3xl mb-3">??</div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Security Deposit Guide</h3>
              <p className="text-gray-600 mb-4">
                Coming soon: How to protect and recover your deposit
              </p>
              <div className="text-gray-500 font-medium">
                Coming soon
              </div>
            </div>
          </div>

          <div className="mt-12 bg-gradient-to-br from-green-50 to-blue-50 rounded-xl p-8 border-2 border-green-200">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">?? Quick Money-Saving Tips</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Before Signing</h3>
                <ul className="space-y-2 text-gray-700">
                  <li>? Negotiate rent (save $50-200/month)</li>
                  <li>? Ask about move-in specials</li>
                  <li>? Waive administrative fees</li>
                  <li>? Sign longer lease for lower rent</li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">While Renting</h3>
                <ul className="space-y-2 text-gray-700">
                  <li>? Get a roommate (save 40-50%)</li>
                  <li>? Bundle utilities and services</li>
                  <li>? Use less peak electricity</li>
                  <li>? Shop renters insurance annually</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
